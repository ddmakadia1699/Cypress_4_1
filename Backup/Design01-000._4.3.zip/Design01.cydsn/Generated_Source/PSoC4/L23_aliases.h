/*******************************************************************************
* File Name: L23.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_L23_ALIASES_H) /* Pins L23_ALIASES_H */
#define CY_PINS_L23_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define L23_0			(L23__0__PC)
#define L23_0_PS		(L23__0__PS)
#define L23_0_PC		(L23__0__PC)
#define L23_0_DR		(L23__0__DR)
#define L23_0_SHIFT	(L23__0__SHIFT)
#define L23_0_INTR	((uint16)((uint16)0x0003u << (L23__0__SHIFT*2u)))

#define L23_INTR_ALL	 ((uint16)(L23_0_INTR))


#endif /* End Pins L23_ALIASES_H */


/* [] END OF FILE */
