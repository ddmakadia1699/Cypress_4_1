

/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdlib.h"
#include "cyapicallbacks.h"


void updateLoad(void);
void loadWrite(uint8,uint8);
void put_fanon(uint8,uint8);
void put_fanledon(uint8,uint8);
void HandleError(void);
void i2cReceive(void);
void ReadSceneButton(void);
//#define digitalWrite(pin,state) (L##pin##_Write)(state)

#define LightloadNumber 4
#define FanLoadNumber 1

uint8 state_switch[LightloadNumber];       //status of touch switch
uint8 pre_switch[LightloadNumber];         //previous status of touch switch
uint8 state_load[LightloadNumber];         //status of load
uint8 state[LightloadNumber + FanLoadNumber];   //state for communication 
uint8 pre_state[LightloadNumber + FanLoadNumber];   //state for communication 
uint8 state_Fswitch[FanLoadNumber];   //status of fan switch
uint8 pre_Fswitch[FanLoadNumber];    //previous status of fan switch
uint8 fan_state[FanLoadNumber][2];
uint8 state_Fan[FanLoadNumber];    //status of fan regulator
uint8 pre_state_fan[FanLoadNumber];
uint8 pre_Fan[FanLoadNumber];     //previous status of fan regulator
uint8 c_lock[LightloadNumber + FanLoadNumber];  //status of child lock
uint8 pre_c_lock[LightloadNumber + FanLoadNumber];

uint8 Switch[] = {0,1,2,3};   // touch swich for light load(cap sense button 0,1,2,3)
uint8 Load[] = {0,1,2,3};  //load connection for switch (L0,L1,L2,L3)(relay)
uint8 F_switch[] = {6}; //fan touch switch (cap sense button 4)
uint8 F_UP_DWN[][2] = {{4,5}}; //fan up and down touch switch(cap sense button 5,6)
uint8 Fan[][4] = {{4,5,6,7}};  //fan output connection(L4,L5,L6,L7)
uint8 Fan_led[][5] = {{8,9,10,11,12}}; // fan speed indicator led(L8,L9,L10,L11,L12)
uint8 white_led_load[] = {13,14,15,16}; //white led for each load(L13,L14,L15,L16)
uint8 Fan_BW[][2] = {{20,19}};   //fan blue and white led 
uint8 Fan_UDW[][2] = {{17,18}};  //fan up down white led
uint8 Fan_UDB[][2] = {{21,22}};  //fan up down blue led
uint8 scene_BW[2] = {24,23};  //aspire switch up down blue led

uint8 Scenebut = {7};  //touch switch for aspire pad(cap sense button 7)
uint8 ScenebutStatus = 0;
uint8 pre_ScenebutStatus = 0;
uint8 whiteLed = 1;      //status of activation of white led of all loads
 
//i2c
uint8 i2cReadBuffer[2*(LightloadNumber + FanLoadNumber) + 5];
uint8 i2cWriteBuffer[15];
uint8 I2CFlag = 0u;

uint8 sceneled = 0;
uint8 reset_flag = 0;
uint8 onOff_flag = 0;
uint8 resetCOM_flag = 0;
uint8 format_flag = 0;
uint8 b_flag = 0;
uint8 pre_onOff_flag = 1;
uint8 pre_reset_flag = 2;
uint8 pre_resetCOM_flag = 1;
uint8 pre_format_flag = 1;

#define TIME_MS_IN_SEC      (100000u)
uint32 msCount;
volatile uint32 tickStatus;
uint8 stateFOR = 1;

uint8 test_flag = 0;
void SysTickISRCallback(void)
{
    tickStatus = 1u;
    if(msCount != 0u  && test_flag == 1)
    {
        --msCount;
        test_flag = 0;
    }
    else
    {
        msCount = TIME_MS_IN_SEC - 1u;
        test_flag = 0;
    }
}

void I2C_I2C_ISR_ExitCallback()
{
    I2CFlag = 1; 
}

int main(void)
{
    //uint8 resetSource = *(reg32 *)CYREG_RES_CAUSE;
    //if (resetSource != 0) /* Source is not initial power or reset */
    //{
        //reset_flag = 1;
    //}
    //reset_flag = *(reg32 *)CYREG_RES_CAUSE;
    reset_flag = *(reg32 *)CYREG_RES_CAUSE;
    reset_flag = reset_flag & 0b11101111;
    if(reset_flag != 0)
        reset_flag = 1;
    memset(state_switch,0,sizeof(state_switch));
    memset(pre_switch,0,sizeof(pre_switch));
    memset(state,0,sizeof(state));
    memset(state_load,0,sizeof(state_load));
    memset(pre_state,0,sizeof(pre_state));
    memset(state_Fswitch,0,sizeof(state_Fswitch));
    memset(pre_Fswitch,0,sizeof(pre_Fswitch));
    memset(fan_state,0,sizeof(fan_state));
    memset(fan_state,0,sizeof(fan_state));
    memset(pre_state_fan,0,sizeof(pre_state_fan));
    memset(pre_Fan,0,sizeof(pre_Fan));
    memset(i2cReadBuffer,0,sizeof(i2cReadBuffer));
    memset(c_lock,0,sizeof(c_lock));
    memset(pre_c_lock,0,sizeof(pre_c_lock));
        
      
    /* Set up the I2C Buffers and start the I2C Component. PSOC as slave */
    I2C_I2CSlaveInitReadBuf(i2cReadBuffer, 2*(LightloadNumber + FanLoadNumber) + 5);
    I2C_I2CSlaveInitWriteBuf(i2cWriteBuffer, 15);
    
     /* Interrupt handler */
    I2C_I2C_ISR_ExitCallback();
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //watch dog initialization(2 second)
    /* Set the second WDT counter to generate reset on match */
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER1, CY_SYS_WDT_MODE_RESET);
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER1, 0xFA00);
      
     /* Counter 1 is cleared when there is match */
    CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER1, 1u);
    
    /* Counter 1 is enabled */
    CySysWdtEnable(CY_SYS_WDT_COUNTER1_MASK);
    
    CapSense_1_Start();
    CapSense_1_ScanAllWidgets();    
    I2C_Start();
    
    uint32 i;
    tickStatus = 0u;
    msCount = TIME_MS_IN_SEC - 1u;
    
    CySysTickStart();
    
    for (i = 0u; i < CY_SYS_SYST_NUM_OF_CALLBACKS; ++i)
    {
        if (CySysTickGetCallback(i) == NULL)
        {
            CySysTickSetCallback(i, SysTickISRCallback);
            break;
        }
    }
       

    for(;;)
    {
        if(CapSense_1_NOT_BUSY == CapSense_1_IsBusy()){
           
            CapSense_1_ProcessAllWidgets();
            updateLoad();
            /* Start scanning all enabled sensors */
            CapSense_1_ScanAllWidgets();
        }
      
        
        //ReadSceneButton();
        if(I2CFlag != 0)
        {
            I2CFlag = 0;  
            if (0u != (I2C_I2C_SSTAT_WR_CMPLT & I2C_I2CSlaveStatus()))
            {
                i2cReceive();
                
                /* Clear the slave write buffer for next write */
                I2C_I2CSlaveClearWriteBuf();
                (void) I2C_I2CSlaveClearWriteStatus();
            }
            /* Read Complete: Expose buffer to master */
            if(0u != (I2C_I2C_SSTAT_RD_CMPLT & I2C_I2CSlaveStatus()))
            {
                /* Clear the slave read buffer for next read */
                I2C_I2CSlaveClearReadBuf();
                (void) I2C_I2CSlaveClearReadStatus();
            }          
        }
        //if status of any of the load changes, update the i2c master on the change.
        for(uint8 i = 0 ; i < LightloadNumber + FanLoadNumber ; i++){
            if(state[i] != pre_state[i]){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    pre_state[i] = state[i];
                    i2cReadBuffer[i] = state[i];
                }
            }
            if(c_lock[i] != pre_c_lock[i]){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    pre_c_lock[i] = c_lock[i];
                    i2cReadBuffer[i+ LightloadNumber + FanLoadNumber] = c_lock[i];
                }
            }
            if(reset_flag != pre_reset_flag){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber) + 1] = reset_flag;    
                    pre_reset_flag = reset_flag;
                }
            }
            if(onOff_flag != pre_onOff_flag){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber) + 2] = onOff_flag;    
                    pre_onOff_flag = onOff_flag;
                }
            }
            if(resetCOM_flag != pre_resetCOM_flag){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber) + 3] = resetCOM_flag;    
                    pre_resetCOM_flag = resetCOM_flag;
                }
            }
            if(format_flag  != pre_format_flag){
                if((I2C_I2C_SSTAT_RD_BUSY & I2C_I2CSlaveStatus()) == 0){
                    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber) + 4] = format_flag;    
                    pre_format_flag = format_flag;
                }
            }
        }
        if(tickStatus != 0u)
        {
            tickStatus = 0u;
            if (CapSense_1_IsWidgetActive(Scenebut)) 
            {   
                test_flag = 1;
                if(msCount)
                {
                    //char time[16u];
                    //sprintf(time, "\r%02lu", msCount);
                    //UART_PutString(time);
                    b_flag = 1;
                    
                }
            }
            //else if ((!CapSense_1_IsWidgetActive(Scenebut) && b_flag == 1 && onOff_flag == 0) || (!CapSense_1_IsWidgetActive(Scenebut) && b_flag == 1 && resetCOM_flag == 0))
            else if ((!CapSense_1_IsWidgetActive(Scenebut) && b_flag == 1 ) || (!CapSense_1_IsWidgetActive(Scenebut) && b_flag == 1 ))
            {
                b_flag = 0;
                if(msCount > 98000 || msCount == 0){  // max 5 sec
                    //UART_PutString(" Scene ");
                    ReadSceneButton();
                    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber)] = !i2cReadBuffer[2*(LightloadNumber + FanLoadNumber)];
                    pre_ScenebutStatus = ScenebutStatus;
                    //msCount=99998;
                }
                else if (msCount > 85000 && msCount < 95000){  // 5 sec to 15 sec
                    //UART_PutString(" onOff Flag ");
                    onOff_flag = 1;
                    //msCount=99998;
                }
                else if(msCount > 50000 && msCount < 75000){ // 25 sec to 40 sec
                    //UART_PutString(" reset Flag ");
                    resetCOM_flag = 1;
                    //msCount=99998;
                }
                else if(msCount < 50000){   // after 50 sec
                    //UART_PutString(" reset Flag ");
                    format_flag = 1;
                    //msCount=99998;
                }
                msCount=99998; 
            }
            //msCount=0;
            //ReadSceneButton();
        }
        CySysWatchdogFeed(CY_SYS_WDT_COUNTER1);
    }
}
//this fuction reads status of the aspie button and updates the i2c master(cap sense button 7)
void ReadSceneButton(void){
    ScenebutStatus = CapSense_1_IsWidgetActive(Scenebut);
    if(ScenebutStatus != pre_ScenebutStatus && ScenebutStatus != 0){
    i2cReadBuffer[2*(LightloadNumber + FanLoadNumber)] = !i2cReadBuffer[2*(LightloadNumber + FanLoadNumber)];
    pre_ScenebutStatus = ScenebutStatus;
    }else if(ScenebutStatus != pre_ScenebutStatus && ScenebutStatus == 0){
        pre_ScenebutStatus = ScenebutStatus;
    }
}

//this fuction deals with received bytes from i2c master.
void i2cReceive(void){
    uint8 count = 0;
    char start_m = i2cWriteBuffer[count];
    count++;
    if (start_m == 's') {                              //load 0 to 3 on and off
        //onlinestatus_flag = 's';
        for (uint8 i = 0; i < LightloadNumber; i++) {
            state[i] = i2cWriteBuffer[count];
            if (state[i] == 0) {
                loadWrite(Load[i],0);
                if(whiteLed == 1)
                    loadWrite(white_led_load[i],1);
            }else if (state[i] >= 128) {
                loadWrite(Load[i], 1);
                loadWrite(white_led_load[i],0);
            }
            count++;
        }
        for (uint8 i = 0; i < FanLoadNumber; i++) {               //fan on,off and speed change
            state[LightloadNumber + i] = i2cWriteBuffer[count];
            if(state[LightloadNumber + i]  == 128){
                put_fanon(i,state_Fan[i]);  
                state[LightloadNumber + i] = state[LightloadNumber + i]  + state_Fan[i] + 1;
                loadWrite(Fan_BW[i][0],1);
                loadWrite(Fan_BW[i][1],0); 
            }else if(state[LightloadNumber + i]  > 0 && state[LightloadNumber + i]  <= 5){
                
                put_fanledon(i,state[LightloadNumber + i]);
                state_Fan[i] = state[LightloadNumber + i];
                //state[LightloadNumber + i] = state_Fan[i];
            }
            else{
                put_fanon(i,state[LightloadNumber + i] - 129);
                if(state[LightloadNumber + i] - 129 >=0 && state[LightloadNumber + i] - 129 <= 5){
                    put_fanledon(i,state[LightloadNumber + i] - 129);
                    state_Fan[i] = state[LightloadNumber + i] - 129;
                    loadWrite(Fan_BW[i][0],1);
                    loadWrite(Fan_BW[i][1],0);         
                }else{
                    state[LightloadNumber + i] = state_Fan[i] ;
                    loadWrite(Fan_BW[i][0],0);
                    if(whiteLed == 1)
                        loadWrite(Fan_BW[i][1],1); 
                }
            }
        }
    }else if (start_m == 'l') {                                    //child lock any of the loads. after this you cannot turn on or off the loads using touch pad.
        c_lock[i2cWriteBuffer[count] - '1'] = i2cWriteBuffer[count+1] - '0';
        //onlinestatus_flag = 'l';
    }else if (start_m == 'w') {                              //enable or disable white led
        whiteLed = i2cWriteBuffer[count] - '0';
        if(whiteLed == 0 || whiteLed == 1){
            for (uint8 i = 0; i < LightloadNumber; i++){
                if(state[i] == 0)
                    loadWrite(white_led_load[i],whiteLed);
            }
            for (uint8 i = 0; i < FanLoadNumber; i++) {
                if(state[LightloadNumber + i] <= 5)
                    loadWrite(Fan_BW[i][1],whiteLed);
                loadWrite(Fan_UDW[i][0],whiteLed);
                loadWrite(Fan_UDW[i][1],whiteLed);
            }
            if(sceneled == 0)
                loadWrite(scene_BW[1],whiteLed);    
        }            
    }else if (start_m == 'a') {                      //turn on or off aspire switch blue and white led
        sceneled = i2cWriteBuffer[count] - '0';
        i2cReadBuffer[2*(LightloadNumber + FanLoadNumber)] = sceneled;
        loadWrite(scene_BW[0],sceneled);
        if(whiteLed == 1)
            loadWrite(scene_BW[1],!sceneled);
    }else if (i2cWriteBuffer[0] == 'o' && i2cWriteBuffer[1] == 't' && i2cWriteBuffer[2] == 'a' ) { 
        Bootloadable_1_Load();
    }
    else if (start_m == 'r') {
        reset_flag = 0;
    }
    else if (start_m == 'q') {
        onOff_flag = 0;
    }
    else if (start_m == 'e') {
        resetCOM_flag = 0;
        CySoftwareReset();
    }
    else if (start_m == 'f') {
        format_flag = 0;
    }
    //else if (start_m == 'c') {
        //onlinestatus_flag = 0;
    //}
}
//This function reads the status of all touch pads and turn on the respective loads
void updateLoad(void){
    for(uint8 i = 0 ; i < LightloadNumber ; i++){                       //load 0 to 3 on and off
       state_switch[i] = CapSense_1_IsWidgetActive(Switch[i]);
       if(state_switch[i] != pre_switch[i]){
            if (c_lock[i] == 0) {                                  //if child lock is disabled then turn on or off load
                if(state_switch[i] != 0){
                    if(state[i] != 0)
                        state_load[i] = 0;
                    else 
                        state_load[i] = 1;
                    loadWrite(Load[i],state_load[i]);  
                    state[i] = state_load[i] ? 1 : 0;
                    state[i] = state[i] << 7;
                    if(whiteLed == 1)
                        loadWrite(white_led_load[i],!(state_load[i]));
                }
            }
            pre_switch[i] = state_switch[i];
        }
    }

    for(uint8 i = 0 ; i < FanLoadNumber ; i++){               //fan on,off and speed change
        if (c_lock[LightloadNumber + i] == 0) {    
            state_Fswitch[i] = CapSense_1_IsWidgetActive(F_switch[i]);
            if(CapSense_1_IsWidgetActive(F_UP_DWN[i][0]) != fan_state[i][0]){    //check if fan up touch pad is pressed
                if(CapSense_1_IsWidgetActive(F_UP_DWN[i][0]) != 0){
                    if(state_Fan[i] != 5)
                        state_Fan[i]++;                                 //fan speed increase by 1
                    else
                        state_Fan[i] = 0;
                    fan_state[i][0] = !(fan_state[i][0]);
                    loadWrite(Fan_UDW[i][0],0);              // fan up white led off
                    loadWrite(Fan_UDB[i][0],1);              //fan up blue led on
                }else{
                    
                    loadWrite(Fan_UDB[i][0],0);              //fan up blue led off
                    if(whiteLed == 1)
                        loadWrite(Fan_UDW[i][0],1);          //fan up white led off
                }
                fan_state[i][0] = (CapSense_1_IsWidgetActive(F_UP_DWN[i][0]));
            }
            if(CapSense_1_IsWidgetActive(F_UP_DWN[i][1]) != fan_state[i][1]){             //check if fan down touch pad is pressed
                if(CapSense_1_IsWidgetActive(F_UP_DWN[i][1]) != 0){
                    if(state_Fan[i] != 0)
                        state_Fan[i]--;                             //fan speed decrease by 1
                    else
                        state_Fan[i] = 5;
                fan_state[i][1] = !(fan_state[i][1]);
                loadWrite(Fan_UDW[i][1],0);
                loadWrite(Fan_UDB[i][1],1);
                }else{
                    
                    loadWrite(Fan_UDB[i][1],0);
                    if(whiteLed)
                        loadWrite(Fan_UDW[i][1],1);
                }
                fan_state[i][1] = (CapSense_1_IsWidgetActive(F_UP_DWN[i][1]));
            }
            if(state_Fan[i] != pre_Fan[i] && state[LightloadNumber + i] < 128){   //if speed increased when fan is off, change the speed indicators led but do not turn on fan 
                put_fanledon(i,state_Fan[i]);
                pre_Fan[i] = state_Fan[i];    
                state[LightloadNumber + i] = state_Fan[i];  
            }

            if ((state_Fswitch[i] != pre_Fswitch[i] && state_Fswitch[i] != 0) || state_Fan[i] != pre_Fan[i]){     //if speed increased when fan is on or fan is turned on, change the fan speed. 
                if ((state[LightloadNumber + i] <= 5 && state_Fswitch[i] != pre_Fswitch[i])  || (state_Fan[i] != pre_Fan[i] && state[LightloadNumber + i] != 0)){
                    state[LightloadNumber + i] = 1;
                    state[LightloadNumber + i] = state[LightloadNumber + i] << 7;
                    state[LightloadNumber + i] = state[LightloadNumber + i] + state_Fan[i] + 1;
                    put_fanon(i,state_Fan[i]);
                    put_fanledon(i,state_Fan[i]);
                }else{
                    state[LightloadNumber + i] = state_Fan[i];
                    put_fanon(i,0); 
                    if(pre_Fswitch[i] == state_Fswitch[i])
                        put_fanledon(i,0);
                }
                pre_Fan[i] = state_Fan[i];
                pre_Fswitch[i] = state_Fswitch[i];       
            }else if(state_Fswitch[i] != pre_Fswitch[i] && state_Fswitch[i] == 0){
                pre_Fswitch[i] = state_Fswitch[i];
            } 
        }
    } 
}
//this function turn on fan on different speed.
void put_fanon(uint8 fan_no,uint8 fan){
    if((fan > 0 && fan <=5) || (state[LightloadNumber + fan_no] > 5 && fan == 0)){
        loadWrite(Fan_BW[fan_no][0],1);
        loadWrite(Fan_BW[fan_no][1],0); 
    }
    else{
        loadWrite(Fan_BW[fan_no][0],0);
        if(whiteLed == 1)
            loadWrite(Fan_BW[fan_no][1],1);  
    }
    for (uint8 i = 0; i < 4; i++)
        loadWrite(Fan[fan_no][i], 0);
    switch (fan) {
        case 0:
            break;
        case 1:
            loadWrite(Fan[fan_no][1], 1);
            break;
        case 2:
            loadWrite(Fan[fan_no][2], 1);
            break;
        case 3:
            loadWrite(Fan[fan_no][2], 1);
            loadWrite(Fan[fan_no][0], 1);
            break;
        case 4:
            loadWrite(Fan[fan_no][2], 1);
            loadWrite(Fan[fan_no][1], 1);
            break;
        case 5:
            loadWrite(Fan[fan_no][3], 1);
            break;
    }
}
//turn on and off fan speed indicator led 
void put_fanledon(uint8 fan_no,uint8 fan){
    if(!(fan >= 0 && fan <=5))
        fan = 0;
    if(fan >= 0 && fan <=5){
        for(int k = fan ; k < 5 ; k++)
            loadWrite(Fan_led[fan_no][k],0);

        for(int j = 0 ; j < fan ; j++)
            loadWrite(Fan_led[fan_no][j],1);
    }   
}
//turn on and off all the gpio pins of psoc
void loadWrite(uint8 loadpin,uint8 state){
    switch(loadpin){
        case 0:
            L0_Write(state);
            break;
        case 1:
            L1_Write(state);
            break;
        case 2:
            L2_Write(state);
            break;
        case 3:
            L3_Write(state);
            break;
        case 4:
            L4_Write(state);
            break;
        case 5:
            L5_Write(state);
            break;
        case 6:
            L6_Write(state);
            break;
        case 7:
            L7_Write(state);
            break;
        case 8:
            L8_Write(state);
            break;
        case 9:
            L9_Write(state);
            break;
        case 10:
            L10_Write(state);
            break;
        case 11:
            L11_Write(state);
            break;   
        case 12:
            L12_Write(state);
            break;
        case 13:
            L13_Write(state);
            break;
        case 14:
            L14_Write(state);
            break;
        case 15:
            L15_Write(state);
            break;
        case 16:
            L16_Write(state);
            break;
        case 17:
            L17_Write(state);
            break;
        case 18:
            L18_Write(state);
            break;
        case 19:
            L19_Write(state);
            break;
        case 20:
            L20_Write(state);
            break;
        case 21:
            L21_Write(state);
            break;
        case 22:
            L22_Write(state);
            break;
        case 23:
            L23_Write(state);
            break;
        case 24:
            L24_Write(state);
            break;
    }      
}
void HandleError(void)
{   
    
     /* Disable all interrupts. */
    __disable_irq();
    
    /* Infinite loop. */
    while(1u) {}
}

/* [] END OF FILE */
